﻿using Recipe_App2;
using System;
using System.Collections.Generic;
using System.Linq;

namespace RecipeApp
{
    // Delegate for notifying when a recipe exceeds 300 calories
    public delegate void RecipeCaloriesExceeded(string recipeName, double totalCalories);

    // Main program class
    class Program
    {
        // Collection to store recipes
        static List<Recipe> recipes = new List<Recipe>();

        // Main method
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Recipe App!");

            // Main menu loop
            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Create a new recipe");
                Console.WriteLine("2. Display recipe list");
                Console.WriteLine("3. Exit");

                Console.Write("Select an option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        CreateNewRecipe();
                        break;

                    case "2":
                        DisplayRecipeList();
                        break;

                    case "3":
                        Console.WriteLine("Exiting... Goodbye!");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please select again.");
                        break;
                }
            }
        }

        // Method to create a new recipe
        static void CreateNewRecipe()
        {
            Console.Write("Enter the name of the recipe: ");
            string recipeName = Console.ReadLine();

            // Variables to hold recipe data
            List<Ingredient> ingredients = new List<Ingredient>();
            List<Step> steps = new List<Step>();

            Console.Write("Enter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            Console.Write("Enter the number of steps: ");
            int numSteps = int.Parse(Console.ReadLine());

            // Get user input for ingredients
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\nIngredient {i + 1}:");
                Console.Write("Enter the name: ");
                string name = Console.ReadLine();

                Console.Write("Enter the quantity: ");
                double quantity = double.Parse(Console.ReadLine());

                Console.Write("Enter the unit: ");
                string unit = Console.ReadLine();

                Console.Write("Enter the number of calories: ");
                double calories = double.Parse(Console.ReadLine());

                Console.Write("Enter the food group: ");
                string foodGroup = Console.ReadLine();

                ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
            }

            // Get user input for steps
            for (int i = 0; i < numSteps; i++)
            {
                Console.Write($"Enter step {i + 1}: ");
                string description = Console.ReadLine();

                steps.Add(new Step(description));
            }

            // Create a new recipe
            Recipe recipe = new Recipe(recipeName, ingredients, steps);
            recipes.Add(recipe);

            recipe.RecipeCaloriesExceededEvent += HandleRecipeCaloriesExceeded;

            Console.WriteLine("Recipe created successfully!");
        }

        // Method to display recipe list
        static void DisplayRecipeList()
        {
            if (recipes.Count == 0)
            {
                Console.WriteLine("No recipes created yet!");
                return;
            }

            Console.WriteLine("\nRecipe List:");
            foreach (var recipe in recipes.OrderBy(r => r.Name))
            {
                Console.WriteLine(recipe.Name);
            }

            Console.Write("\nEnter the name of the recipe to display: ");
            string recipeName = Console.ReadLine();

            Recipe selectedRecipe = recipes.FirstOrDefault(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

            if (selectedRecipe != null)
            {
                selectedRecipe.DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Recipe not found!");
            }
        }

        // Event handler for recipe calories exceeded
        static void HandleRecipeCaloriesExceeded(string recipeName, double totalCalories)
        {
            Console.WriteLine($"Warning: {recipeName} has exceeded 300 calories with {totalCalories} calories!");
        }
    }
}

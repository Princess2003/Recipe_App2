﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App2
{
    public class Step
    {
        public string Description { get; }

        // Constructor
        public Step(string description)
        {
            Description = description;
        }
    }
}

﻿using RecipeApp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App2
{

    public class Recipe
    {
        // Properties
        public string Name { get; }
        public List<Ingredient> Ingredients { get; }
        public List<Step> Steps { get; }
        public event RecipeCaloriesExceeded RecipeCaloriesExceededEvent;

        // Constructor
        public Recipe(string name, List<Ingredient> ingredients, List<Step> steps)
        {
            Name = name;
            Ingredients = ingredients;
            Steps = steps;
        }

        // Method to display the recipe including ingredients and steps
        public void DisplayRecipe()
        {
            Console.WriteLine($"\nRecipe: {Name}");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name} ({ingredient.Calories} calories)");
            }

            Console.WriteLine("\nSteps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {Steps[i].Description}");
            }

            // Calculate total calories
            double totalCalories = Ingredients.Sum(i => i.Calories * i.Quantity);
            Console.WriteLine($"\nTotal Calories: {totalCalories}");

            // Check if total calories exceed 300 and notify
            if (totalCalories > 300)
            {
                RecipeCaloriesExceededEvent?.Invoke(Name, totalCalories);
            }
        }
    }
}

